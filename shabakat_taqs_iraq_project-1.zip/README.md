# شبكة طقس العراق

تطبيق طقس عربي مبني بـ HTML وCSS وJavaScript، ويستخدم Open-Meteo لجلب الحالة الحالية والتوقعات.

## التشغيل على الكمبيوتر
افتح `www/index.html` في متصفح حديث مع اتصال إنترنت. بعض المتصفحات تتطلب تشغيله عبر خادم محلي حتى تعمل صلاحية الموقع الجغرافي.

## إنشاء APK باستخدام Capacitor
يتطلب Node.js وAndroid Studio وAndroid SDK.

1. فك ضغط المشروع.
2. افتح الطرفية داخل مجلد المشروع.
3. نفّذ:
   ```bash
   npm install
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. من Android Studio اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5. ستجد APK عادةً في:
   `android/app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات
- لا يحتاج مفتاح API.
- يتطلب الإنترنت لجلب البيانات.
- إذن الموقع يُطلب عند الضغط على زر تحديد الموقع فقط.
- البيانات من Open-Meteo وليست بديلاً عن التحذيرات الرسمية. راجع https://open-meteo.com/ للاطلاع على الترخيص والإسناد.
- هذا المشروع يجهّز المصدر وملفات التغليف؛ ملف APK النهائي يحتاج بناء Android عبر Android Studio أو بيئة Android مناسبة.

## بناء APK تلقائياً من GitHub (يمكن تنفيذ الخطوات من متصفح الهاتف)

1. أنشئ حساباً أو سجّل الدخول إلى https://github.com
2. أنشئ مستودعاً جديداً باسم `shabakat-taqs-iraq`.
3. ارفع محتويات ملف ZIP إلى المستودع (فك ضغطه أولاً؛ ارفع الملفات والمجلدات الموجودة داخله، بما فيها `.github`).
4. افتح تبويب Actions في المستودع وفعّل GitHub Actions إذا طُلب منك ذلك.
5. شغّل سير العمل `Build Android APK` عبر Run workflow، أو انتظر انتهاء البناء بعد رفع الملفات.
6. افتح نتيجة التشغيل الناجحة، وانزل إلى Artifacts، ثم نزّل `shabakat-taqs-iraq-apk`.
7. فك ضغط ملف Artifact على الهاتف، ثم افتح `app-debug.apk` واسمح بالتثبيت من هذا المصدر عند طلب أندرويد.

ملاحظة: ملف debug APK للتجربة والتثبيت اليدوي، وليس إصداراً منشوراً على Google Play. قد تختلف أسماء الأزرار قليلاً حسب واجهة GitHub.
